from kol1atesty import runtests
# Mateusz Zając 411113 Kolokwium I
# 1) Algorytm zaczynam od "odwrócenia" wszystkich wyrazów, tak aby 2 wyrazy były równowarzne wyłącznie wtedy, gdy są równe
#       złożoność tego kroku to O(n), gdyż wymaga iteracji po wszystkich elementach tablicy

# 2) Kolejnym krokiem jest sortowanie tablicy, mające na celu łatwiejsze zliczanie w kroku trzecim
# Używany algorytm sortowania to Radix sort, ponieważ ma złożoność liniową

# 3) Ostatnik krokiem jest iteracja przez talbice i zliczenia ilość powtórzeń każdego elementu(po etapie pierwszym wszystkie równoważne elementy będą identycznie)

# Złożoność całego algorytmu jest liniowa ( O(n) ) pod względem obliczeń oraz O(1) pod względem pamięci


def rotate_if_needed(s):
    i = 0
    while i < len(s) and s[i] == s[len(s)-1-i]:
        i += 1

    if i == len(s):
        return s

    if s[i] > s[len(s)-1-i]:
        return s[::-1]
    else:
        return s


def find_most_common(T):
    last = "A"  # Big letter so will never match
    m = c = 0

    for i in range(len(T)):
        if T[i] == last:
            c += 1
        else:
            if c > m:
                m = c
            c = 1
            last = T[i]

    return m


def g(T):
    for i in range(len(T)):
        T[i] = rotate_if_needed(T[i])

    T.sort()
    print(T)

    m = find_most_common(T)

    # tu prosze wpisac wlasna implementacje
    return m


# Zamien all_tests=False na all_tests=True zeby uruchomic wszystkie testy
runtests(g, all_tests=True)
