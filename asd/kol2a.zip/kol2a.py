from kol2atesty import runtests

def drivers( P, B ):
    # tu prosze wpisac wlasna implementacje
    return []

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( drivers, all_tests = False )